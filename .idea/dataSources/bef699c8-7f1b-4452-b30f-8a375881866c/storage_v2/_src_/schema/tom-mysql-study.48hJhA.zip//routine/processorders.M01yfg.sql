create
    definer = wcdmaria@`%` procedure processorders()
BEGIN
  DECLARE ordernumbers CURSOR
  FOR
  SELECT order_num FROM orders;OPEN ordernumbers;CLOSE ordernumbers;END;

