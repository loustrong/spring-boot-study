create definer = wcdmaria@`%` trigger neworder
    after INSERT
    on orders
    for each row
    SELECT  NEW.order_num INTO @new_order_num;

