create view orderitemsexpanded as
select `tom-mysql-study`.`orderitems`.`order_num`                                              AS `order_num`,
       `tom-mysql-study`.`orderitems`.`prod_id`                                                AS `prod_id`,
       `tom-mysql-study`.`orderitems`.`quantity`                                               AS `quantity`,
       `tom-mysql-study`.`orderitems`.`item_price`                                             AS `item_price`,
       `tom-mysql-study`.`orderitems`.`quantity` * `tom-mysql-study`.`orderitems`.`item_price` AS `expanded_price`
from `tom-mysql-study`.`orderitems`;

