create
    definer = wcdmaria@`%` procedure productpricing(OUT p1 decimal(8, 2), OUT p2 decimal(8, 2), OUT p3 decimal(8, 2))
BEGIN
  SELECT MIN(prod_price) INTO p1 FROM products;SELECT MAX(prod_price) INTO p2 FROM products;SELECT AVG(prod_price) INTO p3 FROM products;END;

