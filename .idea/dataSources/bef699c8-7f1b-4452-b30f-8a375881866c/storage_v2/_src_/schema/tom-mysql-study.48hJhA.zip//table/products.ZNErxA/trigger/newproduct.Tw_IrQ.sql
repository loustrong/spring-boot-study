create definer = wcdmaria@`%` trigger newproduct
    after INSERT
    on products
    for each row
    SELECT 'Product added' INTO @asd;

